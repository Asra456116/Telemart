// owl-carousel
$('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    autoplay: true,
    autoplayTimeout: 10000,
    slideTransition: 'linear',
  
    autoplaySpeed: 1000,
    
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 5
        }
    }
})
// owl-carousel

// Header Active
$(window).scroll(function () {
    var scroll = $(window).scrollTop();
    if (scroll > 0) {
        $("#header").addClass("active");
    } else {
        $("#header").removeClass("active");
    }
});
// Header Active

// Mobile Header Active
$(window).scroll(function () {
    var scroll = $(window).scrollTop();
    if (scroll > 0) {
        $("#header-mobile").addClass("active");
    } else {
        $("#header-mobile").removeClass("active");
    }
});
// Mobile Header Active

// AOS
AOS.init();
// AOS

// Side Nav
function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
// Side Nav
// $(document).ready(function() {
//     $('.card-slider').slick({
//       dots: false,
//       arrows: true,
//       slidesToShow: 4,
//       infinite: false,
//       responsive: [
//         {
//           breakpoint: 1024,
//           settings: {
//             slidesToShow: 3
//           }
//         },
//         {
//           breakpoint: 800,
//           settings: {
//             slidesToShow: 2
//           }
//         },
//         {
//           breakpoint: 600,
//           settings: {
//             slidesToShow: 1
//           }
//         }
//       ]
//     });
//   });